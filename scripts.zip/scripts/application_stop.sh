#!/bin/bash
echo "ApplicationStop: Parando a aplicação existente"
pkill python || true